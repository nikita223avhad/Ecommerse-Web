import { getProducts } from "../services/productService.js";
import {
  getServerCart,removeLocalCart, updateLocalQuantity} from "../services/cartService.js";
import { escapeHtml, productImage } from "../utils/images.js";
import { initLayout } from "../utils/ui.js";

initLayout();
const products = await getProducts();
let serverCart = [];

try {
  serverCart = await getServerCart();
} catch (error) {
  console.error(error);
}

render();

document.addEventListener("click", (event) => {
  const item = event.target.closest("[data-product]");
  if (!item) return;

  const id = Number(item.dataset.product);

  console.log("Clicked product:", id);

  // TODO: create API endpoints for:
  // - update cart quantity
  // - remove cart item
});

function render() {
  const items = serverCart
    .map((line) => ({
      ...line,
      product: products.find(
        (product) => Number(product.id) === Number(line.product_id)
      ),
    }))
    .filter((line) => line.product);

  document.getElementById("cartList").innerHTML =
    items.length
      ? items.map(itemTemplate).join("")
      : `<div class="panel"><p>Your cart is empty.</p></div>`;

  renderSummary(items);
}

function itemTemplate(item) {
  return `<article class="cart-item" data-product="${item.product.id}">
    <div class="cart-thumb">${productImage(item.product, "cart-image")}</div><div><h3>${escapeHtml(item.product.name)}</h3><p class="muted">${escapeHtml(item.product.category || "")}</p><strong>$${item.product.price}</strong></div>
    <div class="qty"><button data-minus>-</button><span>${item.quantity}</span><button data-plus>+</button></div><button class="remove" data-remove>Remove</button>
  </article>`;
}

function renderSummary(items) {
  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const tax = Math.round(subtotal * 0.05);
  document.getElementById("cartSummary").innerHTML = `<h2>Summary</h2><div class="summary-row"><span>Subtotal</span><strong>$${subtotal}</strong></div><div class="summary-row"><span>Tax</span><strong>$${tax}</strong></div><div class="summary-row total"><span>Total</span><strong>$${subtotal + tax}</strong></div><a class="btn primary" href="checkout.html">Checkout</a>`;
}
