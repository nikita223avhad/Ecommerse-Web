import { getOrders } from "../services/orderService.js";
import { getProducts } from "../services/productService.js";
import { requireAuth } from "../utils/auth.js";
import { escapeHtml, productImage } from "../utils/images.js";
import { initLayout } from "../utils/ui.js";

if (!requireAuth()) throw new Error("Authentication required");
initLayout();
const [orders, products] = await Promise.all([getOrders(), getProducts()]);

document.getElementById("ordersList").innerHTML = orders
  .map((order) => {
    const product = products.find((item) => Number(item.id) === Number(order.product_id));
    return `<article class="order-card"><div class="order-product">${product ? productImage(product, "order-image") : ""}<div class="order-top"><div><strong>#${order.id}</strong><p class="muted">${escapeHtml(product?.name || "Product")} | $${order.total_price}</p></div><span class="status">${escapeHtml(order.status || "Placed")}</span></div></div><div class="timeline"><span class="done"></span><span class="done"></span><span class="done"></span><span></span></div></article>`;
  })
  .join("") || `<div class="panel"><p>No orders found.</p></div>`;
