import { getProducts } from "../services/productService.js";
import { getLocalCart, saveLocalCart } from "../services/cartService.js";
import { createOrder } from "../services/orderService.js";
import { requireAuth } from "../utils/auth.js";
import { initLayout, toast } from "../utils/ui.js";

if (!requireAuth()) throw new Error("Authentication required");
initLayout();
const products = await getProducts();
const cart = getLocalCart();
const items = cart.map((line) => ({ ...line, product: products.find((product) => Number(product.id) === Number(line.product_id)) })).filter((line) => line.product);
const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
const tax = Math.round(subtotal * 0.05);

document.getElementById("checkoutSummary").innerHTML = `<h2>Order summary</h2><div class="summary-row"><span>Items</span><strong>$${subtotal}</strong></div><div class="summary-row"><span>Shipping</span><strong>Free</strong></div><div class="summary-row"><span>Tax</span><strong>$${tax}</strong></div><div class="summary-row total"><span>Total</span><strong>$${subtotal + tax}</strong></div>`;

document.getElementById("checkoutForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const first = items[0];
  try {
    await createOrder({ total_price: subtotal + tax, product_id: first?.product_id || 1 });
    saveLocalCart([]);
    toast("Order placed successfully");
    location.href = "orders.html";
  } catch (error) {
    toast(`Backend error: ${error.message}`, "error");
  }
});
